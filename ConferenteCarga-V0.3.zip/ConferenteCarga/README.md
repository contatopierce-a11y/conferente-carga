# Conferente de Carga — V0.3

Primeiro esqueleto Android nativo do projeto.

## Objetivo
- CameraX para câmera em tempo real.
- ML Kit Barcode Scanning para identificar o código do pacote.
- ML Kit Text Recognition para encontrar `#NX813_<parada>`.
- Parser seguro que não inventa a parada.
- Bloqueio de pacote duplicado.
- Estrutura preparada para conferência offline.

## Regra atual validada
`#NX813_7` -> parada 7
`#NX813_31` -> parada 31

## Ferramentas pesquisadas
- Android Gradle Plugin 9.1.2
- Gradle 9.3.1
- Kotlin/Compose Compiler 2.3.21
- Compose BOM 2026.08.00
- CameraX 1.6.2
- ML Kit Barcode Scanning 17.3.0
- ML Kit Text Recognition 16.0.1

## Observação
Este pacote é código-fonte de desenvolvimento. Ainda precisamos testar a câmera e o reconhecimento com etiquetas reais antes de considerar qualquer build como pronto para uso em produção.
