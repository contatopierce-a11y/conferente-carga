package br.com.conferentecarga

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

class MainActivity : ComponentActivity() {
    private val executor = Executors.newSingleThreadExecutor()
    private var status by mutableStateOf("Aguardando câmera…")
    private var lastStop by mutableStateOf<Int?>(null)
    private var lastPackage by mutableStateOf<String?>(null)
    private var lastReadAt = 0L
    private val seenPackages = mutableSetOf<String>()

    private var pendingPreviewView: PreviewView? = null

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        status = if (granted) "Câmera pronta" else "Permissão de câmera negada"
        if (granted) pendingPreviewView?.let { startCamera(it) }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { ScannerScreen() }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            permissionLauncher.launch(Manifest.permission.CAMERA)
        }
    }

    private fun startCamera(previewView: PreviewView) {
        val providerFuture = ProcessCameraProvider.getInstance(this)
        providerFuture.addListener({
            val provider = providerFuture.get()
            val preview = Preview.Builder().build()
            preview.setSurfaceProvider(previewView.surfaceProvider)

            val analysis = ImageAnalysis.Builder()
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .build()

            val busy = AtomicBoolean(false)
            val barcodeScanner = BarcodeScanning.getClient()
            val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)

            analysis.setAnalyzer(executor) { proxy ->
                if (busy.getAndSet(true)) {
                    proxy.close()
                    return@setAnalyzer
                }
                val mediaImage = proxy.image
                if (mediaImage == null) {
                    busy.set(false)
                    proxy.close()
                    return@setAnalyzer
                }
                val image = InputImage.fromMediaImage(mediaImage, proxy.imageInfo.rotationDegrees)
                val barcodeTask = barcodeScanner.process(image)
                val textTask = recognizer.process(image)
                com.google.android.gms.tasks.Tasks.whenAllSuccess<Any>(barcodeTask, textTask)
                    .addOnSuccessListener { results ->
                        val barcodes = results[0] as List<*>
                        val text = results[1] as com.google.mlkit.vision.text.Text
                        val packageId = barcodes.filterIsInstance<com.google.mlkit.vision.barcode.common.Barcode>()
                            .firstOrNull { !it.rawValue.isNullOrBlank() }?.rawValue
                        val stop = LabelParser.findStop(text.text)
                        if (stop != null && packageId != null) {
                            registerScan(stop, packageId)
                        } else if (stop != null) {
                            status = "Parada $stop detectada — procurando ID do pacote…"
                        }
                    }
                    .addOnCompleteListener {
                        busy.set(false)
                        proxy.close()
                    }
            }

            provider.unbindAll()
            provider.bindToLifecycle(this, CameraSelector.DEFAULT_BACK_CAMERA, preview, analysis)
            status = "Scanner ativo"
        }, ContextCompat.getMainExecutor(this))
    }


    private fun registerScan(stop: Int, packageId: String) {
        val now = System.currentTimeMillis()
        if (packageId == lastPackage && now - lastReadAt < 1800L) return
        lastReadAt = now
        lastPackage = packageId
        if (!seenPackages.add(packageId)) {
            status = "⚠ Pacote já conferido — não contado novamente"
            lastStop = stop
            return
        }
        lastStop = stop
        status = "✓ Pacote registrado na parada $stop"
    }

    @androidx.compose.runtime.Composable
    private fun ScannerScreen() {
        val context = LocalContext.current
        Surface(modifier = Modifier.fillMaxSize(), color = Color.Black) {
            Box(modifier = Modifier.fillMaxSize()) {
                AndroidView(
                    factory = {
                        PreviewView(context).also {
                            pendingPreviewView = it
                            if (ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
                                startCamera(it)
                            }
                        }
                    },
                    modifier = Modifier.fillMaxSize()
                )
                Column(
                    modifier = Modifier
                        .align(Alignment.TopCenter)
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Surface(
                        color = Color.Black.copy(alpha = .72f),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text("CONFERENTE", color = Color.White, style = MaterialTheme.typography.titleLarge)
                            Spacer(Modifier.height(4.dp))
                            Text(status, color = Color.White)
                            lastStop?.let { Text("Parada: $it", color = Color.White) }
                            lastPackage?.let { Text("ID: $it", color = Color.White) }
                        }
                    }
                }
                Row(
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .padding(24.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Button(onClick = { seenPackages.clear(); status = "Conferência zerada" }) {
                        Text("Zerar")
                    }
                }
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        executor.shutdown()
    }
}

object LabelParser {
    private val pattern = Regex("#NX\\s*813\\s*[_-]\\s*(\\d{1,3})\\b", RegexOption.IGNORE_CASE)

    fun findStop(text: String): Int? {
        val match = pattern.find(text.uppercase()) ?: return null
        val value = match.groupValues.getOrNull(1)?.toIntOrNull() ?: return null
        return value.takeIf { it in 1..110 }
    }
}
